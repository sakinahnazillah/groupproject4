/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.groupproject;

/**
 *
 * @author kinah,wan,azim,aidil
 */

public abstract class Person {
    private String name; //requirement slide14
    private int personID; //requirement slide14
    
    Person(){}
    
    public void setName(String name){
        this.name=name;
    }
    
    public String getName(){
        return name.toUpperCase();
    }
    
    public void setPersonID(int personID){
        this.personID=personID;
    }
    
    public int getPersonID(){
        return personID;
    }
    
    public abstract void addGrade(double grade);
        
    public abstract double calculateAverage();
    
}
