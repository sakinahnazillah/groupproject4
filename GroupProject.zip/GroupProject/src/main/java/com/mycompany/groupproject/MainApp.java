/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.groupproject;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author kinah,wan,azim,aidil
 */
public class MainApp {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        boolean importReminder=true;
        int userChoice=0;
        int counter=0;
        int exportSave=0;
        boolean stopProgram=true;
        
        
        while(stopProgram){

            if (counter==3){
                counter = 0;
                System.out.println();
                System.out.println("\t=============Gentle Reminder=============="); //requirement slide 19
                System.out.println("\tDo you want to export your data?");
                System.out.print("\tEnter your response (YES to export, other to return back to menu): ");
                String response = sc.nextLine();
                if (response.equalsIgnoreCase("yes")) {
                    userChoice=6; 
                }else{
                    System.out.println("\tPlease remember to export your data next time...");                
                }
            }
                
            if(userChoice!=6){
                System.out.println();
                System.out.println("\t=============================================");
                System.out.println("\t\tStudent Grade Tracker");
                System.out.println("\t=============================================");
                System.out.println("\t1. Add a New Student");
                System.out.println("\t2. Enter Grades for a Student");
                System.out.println("\t3. View Grades for an Existing Student");
                System.out.println("\t4. View a Student's Report (Including Average)");
                System.out.println("\t5. View All Students");
                System.out.println("\t6. Export Data to File");
                System.out.println("\t7. Import Data from File");
                System.out.println("\t8. Exit");
                
                if(importReminder){
                    System.out.println("\t=============================================");
                    System.out.println("\n\tDo you want to import default file before starting the menu?");
                    System.out.print("\tEnter your response (YES to import, other to start menu): ");
                    String response = sc.nextLine();
                    if (response.equalsIgnoreCase("yes")) {
                        importReminder=false;
                        FileManager.importDataFromFile("export.csv");
                        //import default file that has been saved previously (main database)
                    }else{
                        importReminder=false;
                        continue;
                    }
                }else{
                    try{
                        System.out.print("\tEnter your choice (1-8): ");
                        userChoice=sc.nextInt();
                        sc.nextLine();
                    }catch(InputMismatchException e){
                        sc.nextLine();
                        System.out.println("\tERROR: You entered invalid option...");
                    }  
                }                  
            }

            switch (userChoice){
                case 1:
                    System.out.print("\n\tEnter student name (should not contain ';'): ");
                    String name=sc.nextLine();
                    
                    boolean notValidName=false;
                    try{
                        Integer.parseInt(name);
                        System.out.println("\tERROR: Name cannot be digits..."); 
                        break;
                    }catch (NumberFormatException e){
                        for (int i = 0; i < name.length(); i++) {
                            if (Character.isDigit(name.charAt(i))) {
                                System.out.println("\tERROR: Name cannot contain number...");                    
                                notValidName=true;
                                break;
                            }
                        }
                    }

                    if (notValidName){break;}
                    
                    try{
                        System.out.print("\tEnter Person ID: ");
                        int personID=sc.nextInt();sc.nextLine();

                        if(Student.checkPersonIDUnique(personID)){    
                            System.out.println("\tPerson ID is not unique...");
                            break;
                        }

                        System.out.print("\tEnter Student ID (should not contain ';'): ");
                        String studentID=sc.nextLine();

                        if(Student.checkStudentIDUnique(studentID)){
                            System.out.println("\tStudent ID is not unique...");
                            break;
                        }
                        
                        Student s=new Student(name.replaceAll(";", ""),personID,studentID.replaceAll(";", ""));
                        GradeManager.addStudent(s);
                        counter++;
                        
                    }catch(InputMismatchException d){
                        System.out.println("\tERROR: Person ID should only contain numbers...");
                        sc.nextLine();
                    }
                    exportSave++;
                    break;
                    
                case 2:
                    System.out.print("\n\tEnter Student ID: ");
                    String studentID2=sc.nextLine();
                    Student s2=GradeManager.getStudentById(studentID2);
                    if(s2==null){
                        System.out.println("\n\tNo student is found...");
                    }else{
                        System.out.println("\n\tStudent found in the record: " + s2.getName());
                        while(true){
                            try{
                                System.out.print("\n\tEnter grade (0 to 100, -1 to stop): ");
                                double grade=sc.nextDouble();sc.nextLine();
                                if (grade == -1) {break;}
                                if (grade <0 || grade >100){
                                    System.out.println("\tInvalid grade. Please enter between 0 and 100...");
                                }
                                if (grade >=0 && grade <=100){
                                    s2.addGrade(grade);
                                }
                            }catch(InputMismatchException e){
                                System.out.println("\tERROR: Grade should be digits...");
                                sc.nextLine();
                            }
                        }
                        counter++;
                    }
                    exportSave++;
                    break;
                    
                case 3:
                    System.out.print("\n\tEnter Student ID: ");
                    String studentID3=sc.nextLine();
                    Student s3=GradeManager.getStudentById(studentID3);
                    if(s3==null){
                        System.out.println("\n\tNo student is found...");
                    }else{                        
                        System.out.println();
                        System.out.println(String.format("\t%-15s: %s", "Name", s3.getName()));
                        ArrayList<Double> grades=s3.getGrades();
                        if(grades.isEmpty()){
                            System.out.println(String.format("\t%-15s: %s", "Grade", "No grades entered yet"));
                        }
                        else{
                            for(int i=0;i<grades.size();i++){
                                System.out.println(String.format("\t%s %-9d: %s", "Grade", i+1, grades.get(i)));
                            }
                            
                        }
                    }
                    break;
                    
                case 4:
                    System.out.print("\n\tEnter Student ID: ");
                    String studentID4=sc.nextLine();
                    Student s4=GradeManager.getStudentById(studentID4);
                    if(s4==null){
                        System.out.println("\n\tNo student is found...");
                    }else{
                        System.out.println();
                        System.out.println(String.format("\t%-15s: %s", "Name", s4.getName()));
                        System.out.println(String.format("\t%-15s: %d", "Person ID", s4.getPersonID()));
                        System.out.println(String.format("\t%-15s: %s", "Student ID", s4.getStudentID()));

                        ArrayList<Double> grades = s4.getGrades();
                        
                        if (grades.isEmpty()) {
                            System.out.println(String.format("\t%-15s: %s", "Grade", "No grades entered yet"));
                        } else {
                            for (int i = 0; i < grades.size(); i++) {
                                System.out.println(String.format("\t%-15s: %.1f", "Grade " + (i + 1), grades.get(i)));
                            }
                            System.out.println(String.format("\t%-15s: %.1f", "Average Grade", s4.calculateAverage()));
                        }
                    }
                    break;
                    
                case 5:
                    System.out.println();
                    GradeManager.displayAllStudents();
                    break;
                    
                case 6:
                    System.out.println("\n\tFile will be exported to .csv file...");
                    System.out.println("\tDo you want to save to new file or default file?");
                    System.out.println("\t1.New file");
                    System.out.print("\t2.Default file");
                    System.out.print("\n\tEnter your choice:");
                    int temp1=0;
                    String temp2=null;
                    try
                    {
                        temp1=sc.nextInt();
                        
                    }
                    catch(InputMismatchException e)
                    {
                        System.out.println("\tYou have entered other than number!");
                        System.out.println("\tYou will exit from exporting the file!");
                        sc.nextLine();
                        break;
                    }
                    
                    //user define filename
                    if(temp1==1)
                    {
                        sc.nextLine();
                        System.out.print("\n\tPlease enter the file name: ");
                        temp2=sc.nextLine();
                        FileManager.exportDataToFile(temp2 + ".csv");
                        exportSave=0;

                    }
                    
                    //if user want to use default, and replace the default file
                    else if(temp1==2)
                    {
                        sc.nextLine();
                        System.out.println("\tYou have chosen to export to default file.");
                        System.out.println("\tPlease remember if you does not import the default file when initiating the program the current data inside the default file will be overwritten!");
                        System.out.println("\tDo you still want to export to default file?(Yes/No)");
                        System.out.print("\n\tPlease enter your choice:");
                        temp2=sc.nextLine();
                        if("yes".equalsIgnoreCase(temp2)){
                        FileManager.exportDataToFile("export.csv");
                        exportSave=0;   
                        }
                        else{
                            break;
                        }
                    }
                    break;
 
                case 7:
                    //user need to input filename
                    System.out.println("\n\tOnly .csv files is accepted...");
                    System.out.print("\n\tEnter filepath (eg. \"c:\\File\\ImportList.csv\"): ");
                    String importFilePath=sc.nextLine();
                    
                    if (importFilePath.endsWith(".csv") || importFilePath.endsWith(".CSV")) { 
                        FileManager.importDataFromFile(importFilePath);  
                    }else{
                        System.out.println("\n\tERROR: Only .csv file is accepted...");
                    }
                    
                    break;
                   
                    
                case 8:
                    System.out.print("\n\tEnter YES to confirm exit, other to return back to menu: ");
                    String userConfirmation=sc.nextLine();
                    
                    if (userConfirmation.equalsIgnoreCase("yes")){
                        System.out.println("\n\tSee You Again!");
                        System.out.println();
                        if(exportSave>0){
                            System.out.println("\n\tNote: We have exported your data in case you forgot...");
                            FileManager.exportDataToFile("exportsavebackup.csv");
                            break;
                        }
                        stopProgram=false;
                        break;
                    }
                    break;
                    
                default:
                    System.out.println("\tInvalid choice. Please select between 1-8 only...");
                    break;
            }
            userChoice=0;
        }
    }
}

















