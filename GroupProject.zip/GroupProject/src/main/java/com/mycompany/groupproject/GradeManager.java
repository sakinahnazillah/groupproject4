/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.groupproject;

import java.util.ArrayList;

/**
 *
 * @author kinah,wan,azim,aidil
 */

public class GradeManager {
    
    public static ArrayList<Student> students = new ArrayList<>(); 
    
    static void addStudent(Student student) //requirement slide 5
    {
        students.add(student);
        System.out.println("\tStudent is successfully added...");
    }
    
    static Student getStudentById (String studentID){ 
        for (Student student : students){
            if (student.getStudentID().equalsIgnoreCase(studentID)){
                return student; //requirement slide 5 to return student
            }
        }
        return null;
    }
    
    static void displayAllStudents(){
        if (students.isEmpty()) {
            System.out.println("\n\tNo student has been added into the list yet..."); //requirement slide 10
            return;
        }
        
        System.out.println("\tSummary of all students:");
        System.out.println();
        
        System.out.println(String.format("\t%-85s", "-------------------------------------------------------------------------------------"));
        System.out.println(String.format("\t| %-10s | %-20s | %-12s | %-12s | %-15s |", 
            "Index", "Name", "Person ID", "Student ID", "Average Grade"));
        System.out.println(String.format("\t%-85s", "-------------------------------------------------------------------------------------"));
        
        for (Student student : students){            
            Double average = student.calculateAverage();            
            System.out.println(String.format("\t| %-10d | %-20s | %-12d | %-12s | %-15s |",
                    students.indexOf(student), student.getName(), student.getPersonID(), student.getStudentID(), 
                    Double.isNaN(average) ? "No grade" : String.format("%.2f", average)));
        }
        
        System.out.println(String.format("\t%-85s", "-------------------------------------------------------------------------------------"));
        
    }
}
    
    
    
    
    
    
    
    
    
    
    
    
   