/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.groupproject;

import java.util.ArrayList;

/**
 *
 * @author kinah,wan,azim,aidil
 */

public class Student extends Person {
    private String studentID; 
    private ArrayList<Double> grades = new ArrayList<>(); //requirement slide 14
    
    Student(){}
    
    Student(String name, int personID, String studentID){
        super.setName(name);
        super.setPersonID(personID);
        this.studentID=studentID.toUpperCase();
    }
  
    public static boolean checkStudentIDUnique(String studentID){ 
        for(Student existingStudent : GradeManager.students){
            if (existingStudent.studentID.equalsIgnoreCase(studentID)){
                return true;
            }
        }
        return false;
    }
    
    public static boolean checkPersonIDUnique(int personID){
        for(Student existingStudent : GradeManager.students){
            if (existingStudent.getPersonID()== personID){
                return true;
            }
        }
        return false;
    }
    
    public ArrayList<Double> getGrades(){
        return grades;
    }
    
    public String getStudentID(){
        return studentID;
    }
    
    @Override
    public void addGrade(double grade){
        grades.add(grade);
        System.out.println("\tGrade is sucessfully added...");
    }
    
    @Override
    public double calculateAverage(){
        double sumGrade=0;
        for (double grade : grades){
            sumGrade+=grade;
        }
        double averageGrade = sumGrade/grades.size();
        return averageGrade;
    }
}