/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.groupproject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author kinah,wan,azim,aidil
 */

public class FileManager {
    
    public static void exportDataToFile(String filename){
        
        if(GradeManager.students.isEmpty()){
            System.out.println("\n\tNothing to be exported. Student list is empty...");
        }
        else{
            try (FileWriter fw = new FileWriter(filename)){
                String header = "Name;PersonID;StudentID;Grades;AverageGrade";
                fw.write(header+"\n");
               
                for (Student student : GradeManager.students) {   
                    Double average = student.calculateAverage();            
                    
                    fw.write(student.getName() + ";" + student.getPersonID() + ";" 
                            + student.getStudentID()+ ";" + student.getGrades() + ";"
                            + (Double.isNaN(average) ? "No grade" : average) + "\n");
                    
                }
                System.out.println("\tData has been exported sucessfuly to " + filename);
                
            }catch(IOException e){
                
                System.out.println("\tError exporting the file: " + e.getMessage());
                
            }
        }
    }
    
    public static void importDataFromFile(String filename){
        
        int totalOperation=0;
        int totalSuccess=0;
        
        try(FileReader fr=new FileReader(filename);
            BufferedReader br=new BufferedReader(fr)){
            String line;
            
            if (!br.readLine().equalsIgnoreCase("Name;PersonID;StudentID;Grades;AverageGrade")) {
                System.out.println("\n\tERROR: Invalid header. The file must have the header 'Name,PersonID,StudentID,Grades,AverageGrade' to ensure data is importerd correctly...");
                return; 
            }
            
            while((line=br.readLine())!=null){ 
               
                totalOperation++;
                
                if (line.isEmpty()) {
                    continue;
                }
                
                String[] data = line.split(";");
                String name=data[0].trim();
                String studentID=data[2].trim();
               
                //check if name is valid, if not will skip import
                boolean notValidName=false;
                try{
                    Integer.parseInt(name);
                    System.out.println("\n\t" + line + "\n\tImport unsuccessful. Name cannot be digits...");
                    continue;
                }catch (NumberFormatException e){
                    for (int i = 0; i < name.length(); i++) {
                        if (Character.isDigit(name.charAt(i))) {
                            notValidName=true;
                            break;
                        }
                    }
                }
                
                if (notValidName){
                    System.out.println("\n\t" + line + "\n\tImport unsuccessful. Name cannot contain digits...");
                    continue;
                }

                //check if person ID is valid, if not will skip import
                try{
                    Integer.parseInt(data[1].trim());                
                }catch(NumberFormatException e){
                    System.out.println("\n\t" + line + "\n\tImport unsuccessful. Person ID should only contain digits...");
                    continue;
                }
                int personID=Integer.parseInt(data[1].trim());
                
                //check if Person ID and Student ID is unique, if not will skip import
                if(Student.checkPersonIDUnique(personID) || Student.checkStudentIDUnique(studentID)){
                    System.out.print("\n\t" + line + "\n\tImport unsuccessful. ");
                    if (Student.checkPersonIDUnique(personID)) {
                        System.out.println("Person ID " + personID + " already exists...");
                    } 
                    else if (Student.checkStudentIDUnique(studentID)) {
                        System.out.println("Student ID " + studentID + " already exists...");                        
                    }
                    continue;                    
                }
                
                String gradeString;
                String[] gradeList = new String[0]; 
                boolean skipUser=false;
                boolean validGrade=true;
                boolean hasGrade=true;
                
                if(data.length>3){
                    gradeString=data[3].trim().replace("[", "").replace("]","");
                    gradeList = gradeString.split(",");
                    for (String grade : gradeList){
                        if(grade.isEmpty()){ //only have [] brackets in Grade column without grade
                            hasGrade=false;     
                        }else{
                            try{
                                Double.parseDouble(grade);
                            }catch(NumberFormatException e){
                                skipUser=true;
                                break;
                            }
                            double gradeDouble=Double.parseDouble(grade);
                            if (gradeDouble <0 || gradeDouble >100){
                                validGrade=false;
                                break;
                            }              
                        }
                    }
                }else{ //if Grade column is empty without [] brackets
                    hasGrade=false;
                }
                
                if(skipUser){
                   System.out.println("\n\t" + line + "\n\tImport unsuccessful. Grade must be digits...");
                    continue;
                }
                
                if(!validGrade){
                    System.out.println("\n\t" + line + "\n\tImport unsuccessful. Grade must be between 0 and 100...");
                    continue;
                }
                
                //only student that pass all checks above, will reach this line and student will be imported into the program
                System.out.print("\n\t" + line + "\n"); 
                Student student = new Student(name, personID, studentID);
                GradeManager.addStudent(student);
                totalSuccess++;  
                
                if(hasGrade){
                   for (String grade : gradeList){
                        double gradeDouble=Double.parseDouble(grade);
                        student.addGrade(gradeDouble);
                    }
                }else{
                    System.out.println("\tNo grade available to be imported...");
                }
                                              
            }
            
            System.out.println("\n\tTotal operation: " + totalOperation);
            System.out.println("\tSuccess: " + totalSuccess);
            System.out.println("\tFail: " + (totalOperation-totalSuccess + "\n"));
            
        }catch (IOException e){
        
            System.out.println("\tError reading the file: " + e.getMessage());
            
        }
    }
}






